﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace jsontocsvconverter
{
    public partial class Form1 : Form
    {
        string path = "file.json";
        string output = "file.csv";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var serializer = new JavaScriptSerializer();
            string json = File.ReadAllText(path);
            string info = "";
            Regex arrayFinder = new Regex(@"\[(?<items>[^\]]*)\]",RegexOptions.ExplicitCapture);
            string array = arrayFinder.Match(json).Groups["items"].Value;
            string[] arrayobjects = array.Split(new string[] { ",{", ",\n{", ",\n  {" }, StringSplitOptions.None);
            int i = 0;
            foreach(string objects in arrayobjects)
            {
                if(i==0)
                {
                    var information = serializer.Deserialize<Dictionary<string, object>>(objects);
                    foreach(KeyValuePair<string,object> d in information)
                    {
                        info = info + d.Key + ",";
                    }
                    addline(info);
                    info = "";
                    foreach(KeyValuePair<string,object> d in information)
                    {
                        info = info + d.Value.ToString() + ",";
                    }
                    addline(info);
                }
                else
                {
                    string modifiedobject = "{" + objects;
                    var information = serializer.Deserialize<Dictionary<string, object>>(modifiedobject);
                    info = "";
                    foreach(KeyValuePair<string,object> d in information)
                    {
                        info = info + d.Value.ToString() + ",";
                    }
                    addline(info);
                }
                i++;
            }
        }
        public void addline(string s)
        {
            if(!File.Exists(output))
            {
                File.Create(output).Dispose();
            }
            s = s.Remove(s.Length - 1);
            s = s + "\n";
            File.AppendAllText(output, s);
        }
    }
}
